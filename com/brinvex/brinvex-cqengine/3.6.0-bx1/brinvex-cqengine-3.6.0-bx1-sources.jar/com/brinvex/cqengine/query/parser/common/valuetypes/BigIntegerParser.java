/**
 * Copyright 2012-2015 Niall Gallagher
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.cqengine.query.parser.common.valuetypes;

import com.brinvex.cqengine.query.parser.common.ValueParser;

import java.math.BigInteger;

/**
 * @author Niall Gallagher
 */
public class BigIntegerParser extends ValueParser<BigInteger> {

    @Override
    public BigInteger parse(Class<? extends BigInteger> valueType, String stringValue) {
        return new BigInteger(stringValue);
    }
}
