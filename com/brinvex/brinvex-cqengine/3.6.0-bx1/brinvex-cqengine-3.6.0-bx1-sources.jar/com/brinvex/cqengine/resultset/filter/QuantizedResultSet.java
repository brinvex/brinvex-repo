/**
 * Copyright 2012-2015 Niall Gallagher
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.brinvex.cqengine.resultset.filter;

import com.brinvex.cqengine.quantizer.Quantizer;
import com.brinvex.cqengine.query.Query;
import com.brinvex.cqengine.query.option.QueryOptions;
import com.brinvex.cqengine.resultset.ResultSet;

/**
 * An implementation of {@link FilteringResultSet} which filters objects based on whether they match a given query.
 * <p/>
 * This can be useful to index which use a {@link Quantizer}.
 *
 * @author Niall Gallagher
 */
public class QuantizedResultSet<O> extends FilteringResultSet<O> {

    final Query<O> query;

    public QuantizedResultSet(ResultSet<O> wrappedResultSet, Query<O> query, QueryOptions queryOptions) {
        super(wrappedResultSet, query, queryOptions);
        this.query = query;
    }

    @Override
    public boolean isValid(O object, QueryOptions queryOptions) {
        return query.matches(object, queryOptions);
    }

    @Override
    public Query<O> getQuery() {
        return query;
    }
}
